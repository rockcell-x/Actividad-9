using System.Collections.Generic;
using UnityEngine;

public class PoolManager : Singleton<PoolManager>
{
    [SerializeField] string targetTag;
    [SerializeField] GameObject prefab;
    [SerializeField] List<GameObject> objectPool;

    public void AddToPool(GameObject obj)
    {
        objectPool.Add(obj);
    }

    public GameObject AddToPool(Vector2 position)
    {
        foreach (GameObject obj in objectPool)
        {
            if(!obj.activeSelf)
            {
                obj.SetActive(true);
                obj.transform.position = position;
                return obj;
            }
        }

        GameObject instance = Instantiate(prefab, position, Quaternion.identity);

        objectPool.Add(instance);

        return instance;
    }

    public void RemoveFromPool(GameObject obj)
    {
        objectPool.Remove(obj);
    }

    public void Deacivate(GameObject obj)
    {
        if(objectPool.Contains(obj))
        {
            obj.SetActive(false);
        }
    }

    public void Clear()
    {
        objectPool.Clear();
    }
}
