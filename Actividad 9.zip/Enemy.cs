using UnityEngine;


public class Enemy : MonoBehaviour
{
    public float speed = 2f;
    public float lowerYLimit = -6f;
    public GameObject Bullet; // Prefab de la bala
    public float bulletSpeed = 5f; // Velocidad de la bala

    void OnEnable()
    {
        InvokeRepeating(nameof(Shoot), 1f, 3f); // Dispara cada 3 segundos
    }

    void OnDisable()
    {
        CancelInvoke(nameof(Shoot));
    }

    void Update()
    {
        // Mover hacia abajo
        transform.Translate(Vector2.down * speed * Time.deltaTime);

        // Si sale de la pantalla, reaparece arriba
        if (transform.position.y < lowerYLimit)
        {
            float x = Random.Range(-2.5f, 2.5f);
            float y = 6f; // posición superior fija
            transform.position = new Vector3(x, y, 0);
        }
    }

    public void TakeHit()
    {
        gameObject.SetActive(false); // Desactiva el enemigo (para pooling)
        GameManager.Instance.AddScore(10); // Suma puntos
    }

    void Shoot()
    {
        Instantiate(Bullet, transform.position, Quaternion.identity);
    }
}