using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject Enemyprefab;
    public int poolSize = 6;
    public float spawnInterval = 2f;
    public float xMin = -2.5f;
    public float xMax = 2.5f;

    private GameObject[] enemyPool;

    private void Start()
    {
        enemyPool = new GameObject[poolSize];

        for (int i = 0; i < poolSize; i++)
        {
            enemyPool[i] = Instantiate(Enemyprefab);
            enemyPool[i].SetActive(false);
        }

        InvokeRepeating(nameof(SpawnEnemy), 0f, spawnInterval);
    }

    void SpawnEnemy()
    {
        for (int i = 0; i < poolSize; i++)
        {
            if (!enemyPool[i].activeInHierarchy)
            {
                float randomX = Random.Range(xMin, xMax);
                float yTop = Camera.main.ViewportToWorldPoint(new Vector3(0, 1.1f, 0)).y;

                enemyPool[i].transform.position = new Vector3(randomX, yTop, 0f);
                enemyPool[i].SetActive(true);
                break; // Solo activa uno por ciclo
            }
        }
    }
}