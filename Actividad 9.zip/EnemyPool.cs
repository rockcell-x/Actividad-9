using UnityEngine;
using System.Collections.Generic;

public class EnemyPool : MonoBehaviour
{
    public static EnemyPool Instance;
    public GameObject enemyPrefab;
    public int poolSize = 6;

    private List<GameObject> enemies;

    void Awake()
    {
        Instance = this;
        enemies = new List<GameObject>();
        for (int i = 0; i < poolSize; i++)
        {
            GameObject enemy = Instantiate(enemyPrefab);
            enemy.SetActive(false);
            enemies.Add(enemy);
        }
    }

    public GameObject GetEnemy()
    {
        foreach (var enemy in enemies)
        {
            if (!enemy.activeInHierarchy)
                return enemy;
        }
        return null; // No hay espacio
    }
}
